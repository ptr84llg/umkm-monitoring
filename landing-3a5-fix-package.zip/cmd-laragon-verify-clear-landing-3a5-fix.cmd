@echo off
cd /d C:\laragon\www\umkm-monitoring

echo === STATUS ===
git status

echo.
echo === CEK MUTATIONOBSERVER DI LANDING.JS ===
git grep -n "MutationObserver" -- public/assets/js/pages/landing.js
if errorlevel 1 echo OK: MutationObserver tidak ditemukan di landing.js.

echo.
echo === CLEAR CACHE LARAVEL ===
php artisan optimize:clear
php artisan route:clear
php artisan config:clear
php artisan view:clear

echo.
echo Selesai clear cache.
echo Jalankan server dengan:
echo php artisan serve

pause
