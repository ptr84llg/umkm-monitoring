Batch 3A-7 - Clean landing.blade.php

Cara pakai:
1. Buka PowerShell langsung dari folder project:
   C:\laragon\www\umkm-monitoring

2. Jalankan:
   .\install-landing-blade-3a7-clean.ps1

3. Di CMD-Laragon, jalankan verifikasi manual sesuai instruksi ChatGPT.
