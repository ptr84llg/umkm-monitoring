@echo off
cd /d C:\laragon\www\umkm-monitoring

echo.
echo === GIT STATUS ===
git status

echo.
echo === DIFF STAT ===
git diff --stat

echo.
echo === CEK KOMENTAR BATCH DI LANDING BLADE ===
git grep -n "Batch " -- resources/views/landing.blade.php

echo.
echo === CEK ATTRIBUTE PENTING ===
git grep -n "data-location-gated" -- resources/views/landing.blade.php
git grep -n "data-region-modal" -- resources/views/landing.blade.php
git grep -n "landingMainChart" -- resources/views/landing.blade.php

echo.
echo === CLEAR LARAVEL ===
php artisan optimize:clear
php artisan route:clear
php artisan config:clear
php artisan view:clear

echo.
echo === SELESAI. JALANKAN php artisan serve JIKA SERVER BELUM HIDUP ===
