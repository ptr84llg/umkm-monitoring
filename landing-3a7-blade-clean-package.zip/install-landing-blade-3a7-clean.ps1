$ErrorActionPreference = "Stop"

$Project = (Get-Location).Path
$Target = Join-Path $Project "resources\views\landing.blade.php"

if (-not (Test-Path $Target)) {
    Write-Host "ERROR: File target tidak ditemukan: $Target" -ForegroundColor Red
    exit 1
}

$Backup = "$Target.bak-before-3a7-blade-clean-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
Copy-Item -LiteralPath $Target -Destination $Backup -Force

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$Content = [System.IO.File]::ReadAllText($Target, [System.Text.Encoding]::UTF8)

# Hapus komentar batch lama di Blade. Tidak menyentuh data attribute, class, route, atau isi teks.
$Content = [regex]::Replace(
    $Content,
    "(?m)^\s*\{\{--\s*Batch\s+.*?--\}\}\s*\r?\n?",
    ""
)

# Rapikan div mobile canvas yang menempel setelah modal region.
$Content = [regex]::Replace(
    $Content,
    "\r?\n<div class=""mobile-canvas""",
    "`r`n    <div class=""mobile-canvas"""
)

# Rapikan penutup hero-copy yang sebelumnya turun tanpa indentasi.
$Content = [regex]::Replace(
    $Content,
    "\r?\n</div>\r?\n\s{24}</div>\r?\n\r?\n\s{24}<div class=""col-lg-6"">",
    "`r`n                            </div>`r`n                        </div>`r`n`r`n                        <div class=""col-lg-6"">"
)

# Rapikan penutup chart canvas wrap.
$Content = [regex]::Replace(
    $Content,
    "(<canvas id=""landingMainChart""></canvas>)\r?\n</div>",
    "`$1`r`n                        </div>"
)

# Rapikan blank line berlebih sebelum @endsection dan akhir file.
$Content = [regex]::Replace(
    $Content,
    "\r?\n{3,}@endsection",
    "`r`n@endsection"
)

$Content = [regex]::Replace(
    $Content,
    "\r?\n{3,}$",
    "`r`n"
)

# Normalisasi newline ke CRLF agar konsisten di Windows.
$Content = $Content -replace "\r?\n", "`r`n"

[System.IO.File]::WriteAllText($Target, $Content, $Utf8NoBom)

$After = [System.IO.File]::ReadAllText($Target, [System.Text.Encoding]::UTF8)

if ($After -match "\{\{--\s*Batch\s+") {
    Write-Host "ERROR: Komentar Batch masih ditemukan di landing.blade.php." -ForegroundColor Red
    Write-Host "Backup: $Backup" -ForegroundColor Yellow
    exit 1
}

if ($After -notmatch "data-location-gated") {
    Write-Host "ERROR: data-location-gated tidak ditemukan. Perubahan dibatalkan." -ForegroundColor Red
    Copy-Item -LiteralPath $Backup -Destination $Target -Force
    exit 1
}

if ($After -notmatch "data-region-modal") {
    Write-Host "ERROR: data-region-modal tidak ditemukan. Perubahan dibatalkan." -ForegroundColor Red
    Copy-Item -LiteralPath $Backup -Destination $Target -Force
    exit 1
}

if ($After -notmatch "landingMainChart") {
    Write-Host "ERROR: landingMainChart tidak ditemukan. Perubahan dibatalkan." -ForegroundColor Red
    Copy-Item -LiteralPath $Backup -Destination $Target -Force
    exit 1
}

Write-Host "OK: landing.blade.php berhasil dibersihkan." -ForegroundColor Green
Write-Host "Backup: $Backup" -ForegroundColor Cyan
Write-Host "Target: $Target" -ForegroundColor Cyan
