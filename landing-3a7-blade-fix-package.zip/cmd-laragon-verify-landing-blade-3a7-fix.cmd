@echo off
cd /d C:\laragon\www\umkm-monitoring

echo === GIT STATUS ===
git status

echo.
echo === CEK KOMENTAR BATCH ===
git grep -n "Batch " -- resources/views/landing.blade.php

echo.
echo === CEK ATRIBUT PENTING ===
git grep -n "data-location-gated" -- resources/views/landing.blade.php
git grep -n "data-region-modal" -- resources/views/landing.blade.php
git grep -n "landingMainChart" -- resources/views/landing.blade.php

echo.
echo === CLEAR LARAVEL ===
php artisan optimize:clear
php artisan route:clear
php artisan config:clear
php artisan view:clear

echo.
echo Selesai. Jalankan php artisan serve jika server belum aktif.
