$ErrorActionPreference = "Stop"

$Project = (Get-Location).Path
$Target = Join-Path $Project "resources\views\landing.blade.php"

if (-not (Test-Path $Target)) {
    Write-Host "ERROR: File target tidak ditemukan: $Target" -ForegroundColor Red
    exit 1
}

$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
$Content = [System.IO.File]::ReadAllText($Target, $Utf8NoBom)
$Original = $Content

$Content = $Content.Replace("    </div>`r`n<div class=`"landing-region-modal-shell`" data-region-modal hidden>", "    </div>`r`n`r`n    <div class=`"landing-region-modal-shell`" data-region-modal hidden>")
$Content = $Content.Replace("    </div>`n<div class=`"landing-region-modal-shell`" data-region-modal hidden>", "    </div>`n`n    <div class=`"landing-region-modal-shell`" data-region-modal hidden>")

$Content = $Content.Replace("                                </div>`r`n</div>`r`n                        </div>", "                                </div>`r`n                            </div>`r`n                        </div>")
$Content = $Content.Replace("                                </div>`n</div>`n                        </div>", "                                </div>`n                            </div>`n                        </div>")

$Content = $Content.Replace("                            <canvas id=`"landingMainChart`"></canvas>`r`n</div>", "                            <canvas id=`"landingMainChart`"></canvas>`r`n                        </div>")
$Content = $Content.Replace("                            <canvas id=`"landingMainChart`"></canvas>`n</div>", "                            <canvas id=`"landingMainChart`"></canvas>`n                        </div>")

$Content = [regex]::Replace($Content, "(\r?\n){3,}\z", "`r`n")

if ($Content -eq $Original) {
    Write-Host "INFO: Tidak ada perubahan. File kemungkinan sudah rapi." -ForegroundColor Yellow
    exit 0
}

$Backup = "$Target.bak-before-3a7-blade-fix-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
Copy-Item -LiteralPath $Target -Destination $Backup -Force

[System.IO.File]::WriteAllText($Target, $Content, $Utf8NoBom)

Write-Host "OK: landing.blade.php berhasil dirapikan." -ForegroundColor Green
Write-Host "Backup: $Backup" -ForegroundColor Cyan
Write-Host "Target: $Target" -ForegroundColor Cyan
